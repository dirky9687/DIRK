# DIRK v0.8.0 Beta

**Cardputer ADV firmware for dual-band wireless reconnaissance, Wardrive, and authorized security learning.**

DIRK is a community-editable PlatformIO project. The included `DIRK-v0.8.0.bin` release asset is built for the **M5Stack Cardputer ADV**; the standalone binary and source are provided separately under GitHub Releases.

## What is included

- **Dual-band Wi-Fi discovery:** ESP32-S3 2.4 GHz + **MonsterC5** companion 5 GHz observations in one SSID-first list, with band-specific RSSI.
- **Wardrive:** Wi-Fi/BLE discovery, optional GPS logging with a supported Cap, and on-device Buddy/XP progression.
- **Blue Team:** passive monitoring, saved baselines, anomaly and exposure observations.
- **Red Operations:** authorized wireless assessment, bounded lab tools, service survey, and SD-based findings exports.
- **Attack Learning Labs:** observed lookalike-SSID clues, PMF tabletop simulation, offline WPS checksum demonstration, and a testing playbook. Educational simulations **do not transmit attack frames**.
- **Bluetooth:** BLE advertisement discovery and read-only owned-device assessment with optional CSV exports.
- **Other capabilities:** SD evidence handling, supported IR functionality, and optional expansion interfaces. Actual capabilities depend on connected hardware.

## Hardware requirements

| Component | Purpose | Required? |
|---|---|---|
| M5Stack Cardputer ADV | Display, keyboard, ESP32-S3 2.4 GHz, BLE | Yes |
| MonsterC5 with compatible companion firmware | 5 GHz network discovery | Only for 5 GHz |
| Compatible GPS/LoRa Cap | GPS logging and supported LoRa features | Optional |
| MicroSD | Logs, reports, firmware installation via M5Launcher | Recommended |

The ESP32-S3 **does not itself scan 5 GHz**; that function requires the companion MonsterC5. This firmware does not claim to provide 5 GHz frame injection or full 5 GHz packet capture.

## Install prebuilt firmware

1. Download `DIRK-v0.8.0.bin` from the tagged GitHub Release.
2. Copy the BIN to a microSD card accessible to **M5Launcher** on your Cardputer ADV.
3. Use M5Launcher to select and flash the BIN for the Cardputer ADV.
4. Keep a known-working older BIN as fallback when testing releases.

See your M5Launcher build's own instructions for its menu and flashing workflow. Do not flash this BIN on unrelated ESP32 boards.

## Build and modify the source

Install [PlatformIO](https://platformio.org/) and from the project root run:

```sh
pio run -e cardputer-adv
```

The resulting file is `.pio/build/cardputer-adv/firmware.bin`. The environment is defined in `platformio.ini`; dependencies are obtained by PlatformIO. Review the upstream libraries' licenses and version compatibility before redistributing derivatives.

## Safety and testing

Run active exercises **only on equipment you own or are expressly authorized to assess**, and comply with local radio and cybersecurity laws. RF activity, channel availability, GPS operation, and capture features depend on hardware, regional settings, and test configuration. A report of a transmitted frame does **not** by itself demonstrate that a client was disconnected or that a vulnerability was exploited.

This is a **beta** project. The uploaded v0.8.0 BIN was compiled on the user's setup and reported operational, but independent full-matrix hardware validation, reproduction of the BIN from this cleaned source package, and a comprehensive security review are not complete. See `docs/HARDWARE_VALIDATION.md` and `docs/BETA_TESTING.md`.

## Reporting and contributing

Open a GitHub issue with the firmware version, hardware connected, exact reproduction steps, and a sanitized log. **Do not upload wardrive GPS routes, private SSIDs, captured traffic, credentials, tokens or other personal data.** Pull requests with isolated fixes and test coverage are welcome.

See `CHANGELOG.md`, `SECURITY.md`, `docs/SOURCE_REUSE_MATRIX.md` and `docs/history/` for more information.

## License

Project license identifier: **GPL-3.0-or-later**, as declared by the original source project. See the complete GNU GPL v3 text in `LICENSE`. Third-party libraries, artwork and reused/adapted code remain subject to their own applicable licenses. Confirm source provenance before the first public publication.
